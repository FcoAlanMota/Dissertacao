
import cv2
import os
import time
import numpy as np

###################################################################################################
#def main():
imgOriginal = cv2.imread("img40.jpg") #carrega imagens             
imgOriginal2 = cv2.imread("img41.jpg")
imgOriginal3 = cv2.imread("img42.jpg")
imgOriginal4 = cv2.imread("img43.jpg")
imgOriginal5 = cv2.imread("img44.jpg")

if imgOriginal is None:                             
    print ("Error: Imagem não lida")        
    os.system("pause")                                                      

######## Redimensionando
imgOriginal = cv2.resize(imgOriginal, (640,480))
imgOriginal2 = cv2.resize(imgOriginal2, (640,480))
imgOriginal3 = cv2.resize(imgOriginal3, (640,480))
imgOriginal4 = cv2.resize(imgOriginal4, (640,480))
imgOriginal5 = cv2.resize(imgOriginal5, (640,480))

#Declaração de Variáveis
##Listas
imagens = [imgOriginal, imgOriginal2, imgOriginal3, imgOriginal4, imgOriginal5]

class Variaveis():
    pass
var = Variaveis()
var.teste = 1
var.count = 0
var.flag = 0
var.ind = 0
var.dist = 0
var.qtdF = 5 #quantidade de fotos

######## Saída da função PDI -> encontrar balizas da porta na imagem de entrada
def PDI(imagem):
    #_,frame = cap.read() #captura de video
    hsv = cv2.cvtColor(imagem, cv2.COLOR_BGR2HSV)
    cv2.imwrite("HSV%dn.jpg" %(k),hsv)

######## Filtro de cor: vermelho
    lower_red = np.array([160, 0, 0]) #rgb
    upper_red = np.array([255, 200, 200])
    mask = cv2.inRange(hsv, lower_red, upper_red)
    kernel = np.ones((10,10),np.uint8)
    dilation = cv2.dilate(mask,kernel,iterations = 1)
    #cv2.imshow("Dilatação.jpg",dilation)
    mask = dilation
    res = cv2.bitwise_and(imagem, imagem, mask = mask)
    cv2.imwrite("FiltroVermEDilat%dn.jpg" %(k),res)

######## Binarização
    retval, threshold = cv2.threshold(res, 115, 255, cv2.THRESH_BINARY)
    res = threshold
    cv2.imwrite("Binarização%dn.jpg" %(k),res)
        
######## Morfologia
    kernel = np.ones((16,16),np.uint8)
    opening = cv2.morphologyEx(res, cv2.MORPH_OPEN, kernel) #erosão depois dilata: tirar falsos positivos, ruídos
    res = opening
    return res

while(var.teste):
    for k in range(0,var.qtdF): 
        res = imagens[k]
        cv2.imwrite("Resultado%d.jpg" %(k),PDI(res))
        cv2.imwrite("Original%d.jpg" %(k),imagens[k])
    break
