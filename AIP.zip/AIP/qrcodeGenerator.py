#Gerador QRcodes

import qrcode
from qrcode.image.pure import PyPNGImage

qr = qrcode.QRCode(
    version=1, # 1 a 40; 1 = matriz 21x21; 
    error_correction=qrcode.constants.ERROR_CORRECT_L,
    box_size=10, #quantidade de pixels em cada quadrado do QRcode
    border=4, #quantos quadrados compõem a espessura da borda do QRcode
)

img = qrcode.make('txy')
type(img)  # qrcode.image.pil.PilImage
img.save("qrcode1.png")
